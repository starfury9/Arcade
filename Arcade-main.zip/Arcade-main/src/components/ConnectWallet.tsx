'use client'

import { useEffect, useState } from 'react';
import { useAccount, useBalance, useDisconnect, useReadContract } from 'wagmi';
import { useCircleAuth } from '@/lib/circle/CircleAuthProvider';
import { ConnectWalletModal } from '@/components/ConnectWalletModal';
import { USDC_ADDRESS } from '@/lib/blockchain/contracts/XcrowRouter';
import { arc } from '@/lib/blockchain/arc';

const USDC_DECIMALS = 6;

// Minimal ABI for balanceOf — the project's USDC_ABI only includes
// approve/allowance/nonces.
const USDC_BALANCE_ABI = [
  {
    name: 'balanceOf',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ name: '', type: 'uint256' }],
  },
] as const;

function shortAddress(addr: string): string {
  if (!addr) return '';
  return `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}

function formatUsdc(raw: bigint | undefined): string {
  if (raw === undefined) return '—';
  const whole = raw / BigInt(10 ** USDC_DECIMALS);
  const frac = raw % BigInt(10 ** USDC_DECIMALS);
  if (frac === BigInt(0)) return whole.toString();
  const fracStr = frac.toString().padStart(USDC_DECIMALS, '0').replace(/0+$/, '');
  return `${whole}.${fracStr.slice(0, 2)}`;
}

export function ConnectWallet() {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const { address: eoaAddress, isConnected: eoaConnected } = useAccount();
  const { disconnect } = useDisconnect();

  // Keep wagmi's balance watcher running so EOA balances refresh after txs.
  useBalance({
    address: eoaAddress,
    query: { refetchInterval: 10000, staleTime: 5000 },
  });

  const { wallet: circleWallet, logout: circleLogout, status: circleStatus } =
    useCircleAuth();

  // Circle takes precedence in the pill when both are connected (rare).
  const active = circleWallet
    ? { source: 'circle' as const, address: circleWallet.address }
    : eoaConnected && eoaAddress
      ? { source: 'eoa' as const, address: eoaAddress }
      : null;

  // USDC balance via on-chain read works the same for both wallet types
  // (Circle SCA and EOA both just need their address).
  const { data: usdcRaw } = useReadContract({
    address: USDC_ADDRESS,
    abi: USDC_BALANCE_ABI,
    functionName: 'balanceOf',
    args: active?.address ? [active.address as `0x${string}`] : undefined,
    chainId: arc.id,
    query: {
      enabled: !!active?.address,
      refetchInterval: 12000,
      staleTime: 6000,
    },
  });
  const usdcBalance = formatUsdc(usdcRaw as bigint | undefined);
  void usdcBalance; // referenced in JSX below

  useEffect(() => {
    if (!copied) return;
    const t = setTimeout(() => setCopied(false), 1500);
    return () => clearTimeout(t);
  }, [copied]);

  const handleCopy = async () => {
    if (!active?.address) return;
    try {
      await navigator.clipboard.writeText(active.address);
      setCopied(true);
    } catch {
      // Fallback for older browsers / non-secure contexts
      const ta = document.createElement('textarea');
      ta.value = active.address;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); setCopied(true); } catch { /* noop */ }
      document.body.removeChild(ta);
    }
  };

  if (!active) {
    return (
      <>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-indigo-500 disabled:opacity-60"
          disabled={circleStatus === 'authenticating' || circleStatus === 'creating-wallet'}
        >
          {circleStatus === 'authenticating'
            ? 'Signing in…'
            : circleStatus === 'creating-wallet'
              ? 'Provisioning wallet…'
              : 'Sign in'}
        </button>
        <ConnectWalletModal open={open} onClose={() => setOpen(false)} />
      </>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={handleCopy}
        title={copied ? 'Copied!' : `Copy ${active.address}`}
        aria-label="Copy wallet address"
        className="group flex items-center gap-2 rounded-xl border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm text-white transition hover:border-zinc-700 hover:bg-zinc-900"
      >
        <span
          className="h-2 w-2 rounded-full"
          style={{
            backgroundColor: active.source === 'circle' ? '#6366f1' : '#22c55e',
          }}
          aria-hidden
        />
        <span className="font-mono text-xs text-zinc-300">
          {shortAddress(active.address)}
        </span>
        <span className="h-3 w-px bg-zinc-800" aria-hidden />
        <span className="font-mono text-xs text-zinc-200">
          {usdcBalance} <span className="text-zinc-500">USDC</span>
        </span>
        <span className="text-[10px] uppercase tracking-wider text-zinc-500">
          {active.source === 'circle' ? 'Circle' : 'EVM'}
        </span>
        {copied ? (
          <svg viewBox="0 0 20 20" fill="currentColor" className="h-3.5 w-3.5 text-emerald-400">
            <path fillRule="evenodd" d="M16.7 5.3a1 1 0 010 1.4l-7.5 7.5a1 1 0 01-1.4 0L3.3 9.7a1 1 0 011.4-1.4L8.5 12l6.8-6.7a1 1 0 011.4 0z" clipRule="evenodd" />
          </svg>
        ) : (
          <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-3.5 w-3.5 text-zinc-500 group-hover:text-zinc-300">
            <rect x="6" y="6" width="10" height="10" rx="2" />
            <path d="M4 14V5a1 1 0 011-1h9" strokeLinecap="round" />
          </svg>
        )}
      </button>
      <button
        type="button"
        onClick={() => {
          if (active.source === 'circle') {
            circleLogout();
          } else {
            disconnect();
          }
        }}
        className="rounded-md border border-zinc-800 px-2 py-2 text-xs text-zinc-300 transition hover:border-zinc-700 hover:bg-zinc-900"
      >
        Disconnect
      </button>
    </div>
  );
}
