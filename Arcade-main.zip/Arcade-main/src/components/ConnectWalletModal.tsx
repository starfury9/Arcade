"use client";

import { useCallback, useEffect } from "react";
import { useConnectModal } from "@rainbow-me/rainbowkit";
import { useCircleAuth } from "@/lib/circle/CircleAuthProvider";

type Props = {
  open: boolean;
  onClose: () => void;
};

export function ConnectWalletModal({ open, onClose }: Props) {
  const { openConnectModal } = useConnectModal();
  const { loginWithGoogle, status, error, wallet } = useCircleAuth();

  // Close the modal once a Circle wallet is provisioned.
  useEffect(() => {
    if (open && wallet) onClose();
  }, [open, wallet, onClose]);

  // Close on Escape.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const handleEvm = useCallback(() => {
    onClose();
    // Defer slightly so our overlay unmounts before RainbowKit opens its own.
    setTimeout(() => openConnectModal?.(), 0);
  }, [onClose, openConnectModal]);

  if (!open) return null;

  const busy = status === "authenticating" || status === "creating-wallet";

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Connect to Arcade"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-zinc-800 bg-zinc-950 p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-5 flex items-start justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">
              Connect to Arcade
            </h2>
            <p className="mt-1 text-xs text-zinc-400">
              Arc Testnet · USDC
            </p>
          </div>
          <button
            type="button"
            aria-label="Close"
            className="rounded-md p-1 text-zinc-500 transition hover:bg-zinc-800 hover:text-zinc-200"
            onClick={onClose}
          >
            <svg viewBox="0 0 20 20" className="h-4 w-4" fill="currentColor">
              <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 10-1.06-1.06L10 8.94 6.28 5.22z" />
            </svg>
          </button>
        </div>

        {/* Circle wallet block — primary option */}
        <button
          type="button"
          disabled={busy}
          onClick={loginWithGoogle}
          className="group relative w-full overflow-hidden rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 p-4 text-left transition disabled:cursor-not-allowed disabled:opacity-70 hover:from-indigo-500 hover:to-indigo-600"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-white/15">
                <CircleMark />
              </div>
              <div>
                <div className="text-sm font-semibold text-white">
                  Circle Wallet
                </div>
                <div className="text-xs text-indigo-100/85">
                  Google sign-in · No seed phrase needed
                </div>
              </div>
            </div>
            <span className="rounded-full bg-white/15 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-white">
              Recommended
            </span>
          </div>

          {busy && (
            <div className="mt-3 text-xs text-indigo-100/90">
              {status === "authenticating"
                ? "Opening Google sign-in..."
                : "Provisioning your Arc wallet..."}
            </div>
          )}
        </button>

        {error && (
          <div className="mt-3 rounded-md border border-red-900/60 bg-red-950/40 px-3 py-2 text-xs text-red-300">
            {error}
          </div>
        )}

        {/* Divider */}
        <div className="my-5 flex items-center gap-3 text-[10px] uppercase tracking-wider text-zinc-500">
          <span className="h-px flex-1 bg-zinc-800" />
          Or use EVM wallet
          <span className="h-px flex-1 bg-zinc-800" />
        </div>

        {/* RainbowKit fallback */}
        <button
          type="button"
          onClick={handleEvm}
          className="w-full rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3 text-left transition hover:border-zinc-700 hover:bg-zinc-900/70"
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-white">
                MetaMask, Coinbase Wallet, WalletConnect…
              </div>
              <div className="mt-0.5 text-xs text-zinc-400">
                Bring your own EVM wallet
              </div>
            </div>
            <svg viewBox="0 0 20 20" className="h-4 w-4 text-zinc-500" fill="currentColor">
              <path
                fillRule="evenodd"
                d="M7.21 14.77a.75.75 0 01.02-1.06L10.94 10 7.23 6.29a.75.75 0 111.06-1.06l4.25 4.25a.75.75 0 010 1.06l-4.25 4.25a.75.75 0 01-1.08-.02z"
                clipRule="evenodd"
              />
            </svg>
          </div>
        </button>

        <p className="mt-5 text-[11px] text-zinc-500">
          Connects to Arc Testnet · USDC settlement · Powered by Circle
        </p>
      </div>
    </div>
  );
}

function CircleMark() {
  return (
    <svg
      viewBox="0 0 32 32"
      className="h-5 w-5 text-white"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
    >
      <circle cx="16" cy="16" r="11" />
      <path d="M21 11.5a6.5 6.5 0 100 9" strokeLinecap="round" />
    </svg>
  );
}
