"use client";

import { useAccount } from "wagmi";
import { useCircleAuth } from "@/lib/circle/CircleAuthProvider";

export type WalletSource = "circle" | "eoa";

export type ArcadeWallet = {
  address: `0x${string}` | undefined;
  isConnected: boolean;
  source: WalletSource | null;
  /** Whether this wallet uses Circle's API for tx (SCA) vs direct EOA signing. */
  needsCircleApi: boolean;
};

/**
 * Unified wallet identity hook. Returns whichever wallet is currently active
 * (Circle social-login wallet OR wagmi EOA). Circle takes precedence when both
 * are connected, which is a rare edge case.
 */
export function useArcadeWallet(): ArcadeWallet {
  const { address: eoaAddress, isConnected: eoaConnected } = useAccount();
  const { wallet: circleWallet } = useCircleAuth();

  if (circleWallet?.address) {
    return {
      address: circleWallet.address as `0x${string}`,
      isConnected: true,
      source: "circle",
      needsCircleApi: true,
    };
  }

  if (eoaConnected && eoaAddress) {
    return {
      address: eoaAddress,
      isConnected: true,
      source: "eoa",
      needsCircleApi: false,
    };
  }

  return {
    address: undefined,
    isConnected: false,
    source: null,
    needsCircleApi: false,
  };
}
