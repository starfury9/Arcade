"use client";

import { useCallback, useState } from "react";
import { useWriteContract } from "wagmi";
import type { Abi, AbiFunction } from "viem";
import { useArcadeWallet } from "./useArcadeWallet";
import { useCircleAuth } from "@/lib/circle/CircleAuthProvider";
import { circleApi } from "@/lib/circle/api";
import { getCircleSdk } from "@/lib/circle/sdk";

type Hex = `0x${string}`;

export type WriteContractParams = {
  address: Hex;
  abi: Abi;
  functionName: string;
  args?: readonly unknown[];
  /** Native-token value to send with the call, in wei. */
  value?: bigint;
  /** Chain to send the tx on. Ignored for Circle (it uses the account's chain). */
  chainId?: number;
};

/**
 * Convert a viem ABI + functionName into the function signature string Circle
 * expects: e.g. transfer(address,uint256).
 */
function abiSignature(abi: Abi, functionName: string): string {
  const item = abi.find(
    (i): i is AbiFunction => i.type === "function" && i.name === functionName,
  );
  if (!item) {
    throw new Error(`ABI does not contain function ${functionName}`);
  }
  const types = item.inputs.map((inp) => inp.type).join(",");
  return `${functionName}(${types})`;
}

/** Serialize a JS arg into the string form Circle accepts. */
function serializeArg(value: unknown): unknown {
  if (typeof value === "bigint") return value.toString();
  if (Array.isArray(value)) return value.map(serializeArg);
  if (typeof value === "boolean") return value;
  return value;
}

async function pollForTxHash(
  userToken: string,
  walletId: string,
  contractAddress: string,
  challengeStartedAt: number,
  opts: { intervalMs?: number; timeoutMs?: number } = {},
): Promise<Hex> {
  const intervalMs = opts.intervalMs ?? 1500;
  const timeoutMs = opts.timeoutMs ?? 120_000; // 2 min
  const startedAt = Date.now();

  // Circle's createTransaction returns only `challengeId`. The real
  // transactionId only exists after the challenge completes. We discover it by
  // listing the wallet's most recent transactions and matching by contract
  // address + creation timestamp.
  const lowerContract = contractAddress.toLowerCase();

  while (Date.now() - startedAt < timeoutMs) {
    const { transactions } = await circleApi.listTransactions({
      userToken,
      walletId,
      pageSize: 20,
    });

    // Find the most recent transaction for our contract created after we
    // kicked off the challenge.
    const match = transactions?.find((t) => {
      const created = t.createDate ? Date.parse(t.createDate) : 0;
      const target =
        // Older Circle API returns `contractAddress` on the tx, newer ones
        // surface the destination via different fields; we check both shapes.
        ((t as unknown) as { contractAddress?: string }).contractAddress?.toLowerCase() ===
          lowerContract ||
        ((t as unknown) as { destinationAddress?: string }).destinationAddress?.toLowerCase() ===
          lowerContract;
      return created >= challengeStartedAt - 5000 && target;
    });

    if (match?.txHash) {
      return match.txHash as Hex;
    }
    if (match?.state === "FAILED") {
      throw new Error(
        match.errorDetails ||
          match.errorReason ||
          "Circle transaction failed",
      );
    }
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  throw new Error("Circle transaction timed out waiting for tx hash");
}

export type ArcadeWriteContractResult = {
  /**
   * Mirrors wagmi's writeContractAsync. Resolves with the on-chain tx hash.
   * For Circle wallets, this awaits the challenge UI and polls Circle for the
   * settled tx hash before resolving.
   */
  writeContractAsync: (params: WriteContractParams) => Promise<Hex>;
  /** Fire-and-forget variant. Mirrors wagmi's writeContract. */
  writeContract: (params: WriteContractParams) => void;
  data: Hex | undefined;
  isPending: boolean;
  error: Error | null;
};

export function useArcadeWriteContract(): ArcadeWriteContractResult {
  const wagmiHook = useWriteContract();
  const { source } = useArcadeWallet();
  const { session, wallet: circleWallet } = useCircleAuth();

  const [circleHash, setCircleHash] = useState<Hex | undefined>(undefined);
  const [circleIsPending, setCircleIsPending] = useState(false);
  const [circleError, setCircleError] = useState<Error | null>(null);

  const writeContractAsync = useCallback(
    async (params: WriteContractParams): Promise<Hex> => {
      // EOA path: delegate straight to wagmi.
      if (source !== "circle") {
        return wagmiHook.writeContractAsync(params);
      }

      if (!session?.userToken || !circleWallet?.id) {
        throw new Error("Circle wallet not authenticated");
      }

      setCircleHash(undefined);
      setCircleError(null);
      setCircleIsPending(true);

      try {
        const sig = abiSignature(params.abi, params.functionName);
        const abiParameters = (params.args ?? []).map(serializeArg);

        // Capture the wall-clock time right before kicking off the challenge.
        // We later use it to filter the transactions list and find the one we
        // just created (Circle's createTransaction response gives us only the
        // challengeId; the real transactionId is created when the challenge
        // completes and has to be discovered by listing transactions).
        const challengeStartedAt = Date.now();

        const { challengeId } = await circleApi.createTransaction({
          userToken: session.userToken,
          walletId: circleWallet.id,
          contractAddress: params.address,
          abiFunctionSignature: sig,
          abiParameters,
          amount: params.value ? params.value.toString() : "0",
        });

        const sdk = getCircleSdk();
        sdk.setAuthentication({
          userToken: session.userToken,
          encryptionKey: session.encryptionKey,
        });

        // Execute the challenge. The SDK opens a hidden iframe that may
        // self-show if PIN/security UI is needed (first transaction only).
        await new Promise<void>((resolve, reject) => {
          sdk.execute(challengeId, (error) => {
            if (error) {
              reject(new Error(error.message ?? "Challenge failed"));
              return;
            }
            resolve();
          });
        });

        const hash = await pollForTxHash(
          session.userToken,
          circleWallet.id,
          params.address,
          challengeStartedAt,
        );
        setCircleHash(hash);
        return hash;
      } catch (e) {
        const err = e instanceof Error ? e : new Error(String(e));
        setCircleError(err);
        throw err;
      } finally {
        setCircleIsPending(false);
      }
    },
    [source, session, circleWallet, wagmiHook],
  );

  const writeContract = useCallback(
    (params: WriteContractParams) => {
      void writeContractAsync(params).catch(() => {
        // Errors surface via the `error` field; swallow rejection here so the
        // caller doesn't see an unhandled promise rejection in fire-and-forget mode.
      });
    },
    [writeContractAsync],
  );

  if (source === "circle") {
    return {
      writeContractAsync,
      writeContract,
      data: circleHash,
      isPending: circleIsPending,
      error: circleError,
    };
  }

  return {
    writeContractAsync,
    writeContract,
    data: wagmiHook.data as Hex | undefined,
    isPending: wagmiHook.isPending,
    error: (wagmiHook.error as Error | null) ?? null,
  };
}
