"use client";

import { W3SSdk } from "@circle-fin/w3s-pw-web-sdk";
// The public entry only exports W3SSdk; types re-imported from internal path
// since the SDK doesn't re-export them. Brittle if Circle restructures the build.
import type {
  Configs,
  LoginCompleteCallback,
} from "@circle-fin/w3s-pw-web-sdk/dist/src/types";

const APP_ID = process.env.NEXT_PUBLIC_CIRCLE_APP_ID;

if (!APP_ID && typeof window !== "undefined") {
  console.warn("NEXT_PUBLIC_CIRCLE_APP_ID is not set");
}

export type CircleLoginCompleteCallback = LoginCompleteCallback;

let cachedSdk: W3SSdk | null = null;

export function getCircleSdk(
  onLoginComplete?: CircleLoginCompleteCallback,
  extraConfigs?: Partial<Configs>,
): W3SSdk {
  const baseConfigs: Configs = {
    appSettings: { appId: APP_ID ?? "" },
    ...(extraConfigs ?? {}),
  };

  if (cachedSdk) {
    if (extraConfigs || onLoginComplete) {
      cachedSdk.updateConfigs(baseConfigs, onLoginComplete);
    }
    return cachedSdk;
  }

  cachedSdk = new W3SSdk(baseConfigs, onLoginComplete);
  return cachedSdk;
}

export function resetCircleSdk() {
  cachedSdk = null;
}
