export type DeviceTokenResponse = {
  deviceToken: string;
  deviceEncryptionKey: string;
};

export type InitializeUserResponse = {
  challengeId: string;
};

export type CircleWallet = {
  id: string;
  address: string;
  blockchain: string;
  state: string;
  accountType: string;
  custodyType: string;
  createDate: string;
  updateDate: string;
  walletSetId?: string;
};

export type ListWalletsResponse = {
  wallets: CircleWallet[];
};

export type TokenBalance = {
  token: {
    id: string;
    blockchain: string;
    name: string;
    symbol: string;
    decimals: number;
    isNative: boolean;
    tokenAddress?: string;
  };
  amount: string;
  updateDate: string;
};

export type GetTokenBalanceResponse = {
  tokenBalances: TokenBalance[];
};

async function postCircle<T>(action: string, payload: Record<string, unknown>): Promise<T> {
  const res = await fetch("/api/circle", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, ...payload }),
  });
  const data = await res.json();
  if (!res.ok) {
    const message =
      (data && (data.error || data.message)) || `Circle API ${action} failed`;
    throw new Error(message);
  }
  return data as T;
}

export type CreateTransactionResponse = {
  id: string;
  challengeId: string;
  state: string;
};

export type CircleTransaction = {
  id: string;
  blockchain: string;
  walletId: string;
  state: string;
  txHash?: string;
  errorReason?: string;
  errorDetails?: string;
  createDate?: string;
  updateDate?: string;
};

export type GetTransactionResponse = {
  transaction: CircleTransaction;
};

export const circleApi = {
  createDeviceToken: (deviceId: string) =>
    postCircle<DeviceTokenResponse>("createDeviceToken", { deviceId }),

  initializeUser: (userToken: string) =>
    postCircle<InitializeUserResponse>("initializeUser", { userToken }),

  listWallets: (userToken: string) =>
    postCircle<ListWalletsResponse>("listWallets", { userToken }),

  getTokenBalance: (userToken: string, walletId: string) =>
    postCircle<GetTokenBalanceResponse>("getTokenBalance", {
      userToken,
      walletId,
    }),

  createTransaction: (params: {
    userToken: string;
    walletId: string;
    contractAddress: string;
    abiFunctionSignature: string;
    abiParameters: unknown[];
    amount?: string;
    feeLevel?: "LOW" | "MEDIUM" | "HIGH";
  }) => postCircle<CreateTransactionResponse>("createTransaction", params),

  getTransaction: (userToken: string, transactionId: string) =>
    postCircle<GetTransactionResponse>("getTransaction", {
      userToken,
      transactionId,
    }),

  listTransactions: (params: {
    userToken: string;
    walletId?: string;
    pageSize?: number;
  }) =>
    postCircle<{ transactions: CircleTransaction[] }>(
      "listTransactions",
      params,
    ),
};
