"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
// SocialLoginProvider is declared in types.d.ts but not re-exported from
// the SDK's public entry. Importing via the internal path is brittle but the
// only option until Circle exports it.
import { SocialLoginProvider } from "@circle-fin/w3s-pw-web-sdk/dist/src/types";
import { getCircleSdk, resetCircleSdk } from "./sdk";
import { circleApi, type CircleWallet } from "./api";

type CircleSession = {
  userToken: string;
  encryptionKey: string;
};

type CircleAuthState = {
  session: CircleSession | null;
  wallet: CircleWallet | null;
  status: "idle" | "authenticating" | "creating-wallet" | "ready" | "error";
  error: string | null;
};

type CircleAuthContextValue = CircleAuthState & {
  loginWithGoogle: () => Promise<void>;
  logout: () => void;
};

const STORAGE_KEY = "arcade.circle.session";
const PENDING_DEVICE_KEY = "arcade.circle.pendingDevice";

type PendingDevice = {
  deviceToken: string;
  deviceEncryptionKey: string;
  clientId: string;
  redirectUri: string;
};

const CircleAuthContext = createContext<CircleAuthContextValue | undefined>(
  undefined,
);

function readSession(): CircleSession | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as CircleSession;
  } catch {
    return null;
  }
}

function readPendingDevice(): PendingDevice | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(PENDING_DEVICE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as PendingDevice;
  } catch {
    return null;
  }
}

function writePendingDevice(p: PendingDevice | null) {
  if (typeof window === "undefined") return;
  if (p) {
    window.localStorage.setItem(PENDING_DEVICE_KEY, JSON.stringify(p));
  } else {
    window.localStorage.removeItem(PENDING_DEVICE_KEY);
  }
}

function writeSession(session: CircleSession | null) {
  if (typeof window === "undefined") return;
  if (session) {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  } else {
    window.localStorage.removeItem(STORAGE_KEY);
  }
}

export function CircleAuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<CircleAuthState>({
    session: null,
    wallet: null,
    status: "idle",
    error: null,
  });

  const stateRef = useRef(state);
  stateRef.current = state;

  const finalizeSession = useCallback(async (session: CircleSession) => {
    writeSession(session);
    setState((s) => ({ ...s, session, status: "creating-wallet", error: null }));

    try {
      const existing = await circleApi.listWallets(session.userToken);
      if (existing.wallets && existing.wallets.length > 0) {
        setState((s) => ({
          ...s,
          wallet: existing.wallets[0],
          status: "ready",
          error: null,
        }));
        return;
      }

      const init = await circleApi.initializeUser(session.userToken);
      if (!init.challengeId) {
        throw new Error("Circle initializeUser did not return a challengeId");
      }

      const sdk = getCircleSdk();
      sdk.setAuthentication({
        userToken: session.userToken,
        encryptionKey: session.encryptionKey,
      });

      await new Promise<void>((resolve, reject) => {
        sdk.execute(init.challengeId, (error) => {
          if (error) {
            reject(new Error(error.message ?? "Challenge failed"));
            return;
          }
          resolve();
        });
      });

      const after = await circleApi.listWallets(session.userToken);
      const wallet = after.wallets?.[0] ?? null;

      setState((s) => ({
        ...s,
        wallet,
        status: wallet ? "ready" : "error",
        error: wallet ? null : "Wallet creation returned no wallets",
      }));
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to provision Circle wallet";
      setState((s) => ({ ...s, status: "error", error: message }));
    }
  }, []);

  // Initialize the SDK on mount with the onLoginComplete callback wired up.
  // CRITICAL: if we're returning from a Google OAuth redirect, the SDK's
  // setupInstance immediately fires execSocialLoginStatusCheck, which opens
  // a verify-token iframe. The iframe asks for deviceToken/deviceEncryptionKey
  // back via postMessage. Those values live in this.configs.loginConfigs and
  // would otherwise be lost on this fresh mount. We restore them from
  // localStorage so Circle's verification step can succeed.
  useEffect(() => {
    const pending = readPendingDevice();
    const extraConfigs = pending
      ? {
          loginConfigs: {
            google: {
              clientId: pending.clientId,
              redirectUri: pending.redirectUri,
              selectAccountPrompt: true,
            },
            deviceToken: pending.deviceToken,
            deviceEncryptionKey: pending.deviceEncryptionKey,
          },
        }
      : undefined;

    getCircleSdk((error, result) => {
      // Verification finished (success or failure). Either way, the pending
      // device info is consumed.
      writePendingDevice(null);

      if (error) {
        const message =
          (error as { message?: string })?.message ?? "Google login failed";
        setState((s) => ({ ...s, status: "error", error: message }));
        return;
      }
      if (!result?.userToken || !result?.encryptionKey) {
        setState((s) => ({
          ...s,
          status: "error",
          error: "Google login returned without tokens",
        }));
        return;
      }
      void finalizeSession({
        userToken: result.userToken,
        encryptionKey: result.encryptionKey,
      });
    }, extraConfigs);

    // Rehydrate any cached session (e.g. after a page refresh).
    const stored = readSession();
    if (stored?.userToken && stored?.encryptionKey) {
      void finalizeSession(stored);
    }
  }, [finalizeSession]);

  const loginWithGoogle = useCallback(async () => {
    setState((s) => ({ ...s, status: "authenticating", error: null }));

    try {
      const sdk = getCircleSdk();
      const deviceId = await sdk.getDeviceId();
      const { deviceToken, deviceEncryptionKey } =
        await circleApi.createDeviceToken(deviceId);

      const googleClientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID ?? "";
      const redirectUri =
        typeof window !== "undefined" ? window.location.origin : "";

      sdk.updateConfigs({
        appSettings: { appId: process.env.NEXT_PUBLIC_CIRCLE_APP_ID ?? "" },
        loginConfigs: {
          google: {
            clientId: googleClientId,
            redirectUri,
            // Force Google to show the account-selection / consent screen.
            // Without this, the SDK passes prompt=none, which silently errors
            // for users who haven't previously authorized this OAuth client.
            selectAccountPrompt: true,
          },
          deviceToken,
          deviceEncryptionKey,
        },
      });

      // Persist the device credentials so we can restore them into the SDK
      // after the OAuth redirect, before the verify-token iframe handshake.
      writePendingDevice({
        deviceToken,
        deviceEncryptionKey,
        clientId: googleClientId,
        redirectUri,
      });

      await sdk.performLogin(SocialLoginProvider.GOOGLE);
      // performLogin triggers a full-page redirect to Google. After the user
      // authenticates and Google redirects back, the SDK fires onLoginComplete,
      // which is wired in the mount effect above.
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to start Google login";
      setState((s) => ({ ...s, status: "error", error: message }));
    }
  }, []);

  const logout = useCallback(() => {
    writeSession(null);
    resetCircleSdk();
    setState({ session: null, wallet: null, status: "idle", error: null });
  }, []);

  const value = useMemo<CircleAuthContextValue>(
    () => ({ ...state, loginWithGoogle, logout }),
    [state, loginWithGoogle, logout],
  );

  return (
    <CircleAuthContext.Provider value={value}>
      {children}
    </CircleAuthContext.Provider>
  );
}

export function useCircleAuth() {
  const ctx = useContext(CircleAuthContext);
  if (!ctx) {
    throw new Error("useCircleAuth must be used within CircleAuthProvider");
  }
  return ctx;
}
