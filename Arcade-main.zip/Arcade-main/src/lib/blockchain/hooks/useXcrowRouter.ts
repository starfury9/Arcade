import {
  useReadContract,
  useReadContracts,
  useWaitForTransactionReceipt,
  useSignTypedData,
  usePublicClient,
} from "wagmi";
import { useArcadeWallet } from "@/lib/wallet/useArcadeWallet";
import { useArcadeWriteContract } from "@/lib/wallet/useArcadeWriteContract";
import { useEffect, useState } from "react";
import { parseUnits, keccak256, encodePacked, parseEventLogs, parseSignature } from "viem";
import {
  XCROW_ROUTER_ABI,
  XCROW_ROUTER_ADDRESS,
  XCROW_ESCROW_ABI,
  XCROW_ESCROW_ADDRESS,
  USDC_ADDRESS,
  USDC_ABI,
} from "../contracts/XcrowRouter";
import { ERC8004_REPUTATION_ADDRESS, ERC8004_REPUTATION_ABI } from "../contracts/ERC8004";
import { supabase } from "../../supabase/client";
import { arc } from "../arc";

const USDC_DECIMALS = 6;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type PriceQuote = {
  agentId: bigint;
  baseRate: bigint;
  effectiveRate: bigint;
  reputationScore: bigint;
  multiplier: bigint;
  platformFee: bigint;
  totalCost: bigint;
  quotedAt: bigint;
};

// ---------------------------------------------------------------------------
// Read hooks
// ---------------------------------------------------------------------------

export function useAgentInfo(agentId: bigint) {
  const { data, isLoading, error, refetch } = useReadContract({
    address: XCROW_ROUTER_ADDRESS,
    abi: XCROW_ROUTER_ABI,
    functionName: "getAgentInfo",
    args: [agentId],
    chainId: arc.id,
    query: { enabled: agentId > BigInt(0) },
  });

  const info = data as [string, string, string] | undefined;
  return {
    owner: info?.[0] as `0x${string}` | undefined,
    wallet: info?.[1] as `0x${string}` | undefined,
    uri: info?.[2],
    isLoading,
    error,
    refetch,
  };
}

export function useXcrowQuote(agentId: bigint) {
  const { data, isLoading, error, refetch } = useReadContract({
    address: XCROW_ROUTER_ADDRESS,
    abi: XCROW_ROUTER_ABI,
    functionName: "getQuote",
    args: [agentId],
    chainId: arc.id,
    query: { enabled: agentId > BigInt(0) },
  });

  return { quote: data as PriceQuote | undefined, isLoading, error, refetch };
}

// ---------------------------------------------------------------------------
// Hire agent with EIP-2612 permit — one signature + one tx, no pre-approval
// ---------------------------------------------------------------------------

export function useHireAgent() {
  const { data: hash, writeContractAsync, isPending, error } = useArcadeWriteContract();
  const {
    isLoading: isConfirming,
    isSuccess,
    data: receipt,
  } = useWaitForTransactionReceipt({ hash });
  const { signTypedDataAsync } = useSignTypedData();
  const publicClient = usePublicClient({ chainId: arc.id });
  const { source } = useArcadeWallet();

  const hireAgent = async (
    owner: `0x${string}`,
    agentWallet: `0x${string}`,
    amountUsdc: string,
    taskDesc: string,
    deadlineSec: bigint,
    erc8004AgentId: bigint = BigInt(0),
    /** Required when source === 'circle' (no permit path). Ignored otherwise. */
    agentId?: bigint,
  ) => {
    const amount = parseUnits(amountUsdc, USDC_DECIMALS);
    const taskHash = keccak256(encodePacked(["string"], [taskDesc]));

    // Circle SCA wallets have no private key, so USDC.permit() (ECDSA) can't
    // be signed. Fall back to ERC-20 approve + hireAgent(agentId) two-step.
    if (source === "circle") {
      if (agentId === undefined) {
        throw new Error(
          "Hiring with a Circle wallet requires the Arcade agent ID. Pass `agentId` to JobLifecycle.",
        );
      }

      // Step 1: approve the router to pull USDC.
      await writeContractAsync({
        address: USDC_ADDRESS,
        abi: USDC_ABI,
        functionName: "approve",
        args: [XCROW_ROUTER_ADDRESS, amount],
        chainId: arc.id,
      });

      // Step 2: hire by Arcade agent ID (no permit needed).
      return writeContractAsync({
        address: XCROW_ROUTER_ADDRESS,
        abi: XCROW_ROUTER_ABI,
        functionName: "hireAgent",
        args: [agentId, amount, taskHash, deadlineSec],
        chainId: arc.id,
      });
    }

    // EOA path: sign a USDC permit and hire-by-wallet in one tx.
    const permitDeadline = deadlineSec;

    const nonce = await publicClient!.readContract({
      address: USDC_ADDRESS,
      abi: USDC_ABI,
      functionName: "nonces",
      args: [owner],
    });

    const signature = await signTypedDataAsync({
      domain: {
        name: "USDC",
        version: "2",
        chainId: arc.id,
        verifyingContract: USDC_ADDRESS,
      },
      types: {
        Permit: [
          { name: "owner", type: "address" },
          { name: "spender", type: "address" },
          { name: "value", type: "uint256" },
          { name: "nonce", type: "uint256" },
          { name: "deadline", type: "uint256" },
        ],
      },
      primaryType: "Permit",
      message: {
        owner,
        spender: XCROW_ROUTER_ADDRESS,
        value: amount,
        nonce,
        deadline: permitDeadline,
      },
    });

    const { v, r, s } = parseSignature(signature);

    return writeContractAsync({
      address: XCROW_ROUTER_ADDRESS,
      abi: XCROW_ROUTER_ABI,
      functionName: "hireAgentByWalletWithPermit",
      args: [agentWallet, amount, taskHash, deadlineSec, erc8004AgentId, permitDeadline, Number(v ?? 0), r as `0x${string}`, s as `0x${string}`],
      chainId: arc.id,
    });
  };

  // Parse jobId from the AgentHired event in the receipt
  let jobId: bigint | null = null;
  if (receipt) {
    try {
      const logs = parseEventLogs({
        abi: XCROW_ROUTER_ABI,
        eventName: "AgentHired",
        logs: receipt.logs,
      });
      if (logs.length > 0) {
        jobId = (logs[0].args as { jobId: bigint }).jobId;
      }
    } catch {}
  }

  return { hireAgent, isPending, isConfirming, isSuccess, jobId, error, hash };
}

// ---------------------------------------------------------------------------
// Settle (confirm payment)
// ---------------------------------------------------------------------------

/** CCTP destination domains for cross-chain settlement */
export const CCTP_DOMAINS = {
  0: { label: "Same chain (Arc)", crossChain: false },
  6: { label: "Base", crossChain: true },
  3: { label: "Arbitrum", crossChain: true },
  // 0 as Ethereum domain conflicts with "same chain" — use 10 for Ethereum if needed
} as const;

export type CctpDomainId = keyof typeof CCTP_DOMAINS;

export function useSettleJob() {
  const { data: hash, writeContractAsync, isPending, error } = useArcadeWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  const settleJob = async (jobId: bigint, destinationDomain: number = 0, hookData: `0x${string}` = "0x") => {
    return writeContractAsync({
      address: XCROW_ROUTER_ADDRESS,
      abi: XCROW_ROUTER_ABI,
      functionName: "settleAndPay",
      args: [jobId, destinationDomain, hookData],
      chainId: arc.id,
    });
  };

  return { settleJob, isPending, isConfirming, isSuccess, error, hash };
}

// ---------------------------------------------------------------------------
// Cancel
// ---------------------------------------------------------------------------

export function useCancelJob() {
  const { data: hash, writeContractAsync, isPending, error } = useArcadeWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  const cancelJob = async (jobId: bigint) => {
    return writeContractAsync({
      address: XCROW_ROUTER_ADDRESS,
      abi: XCROW_ROUTER_ABI,
      functionName: "cancelJobViaRouter",
      args: [jobId],
      chainId: arc.id,
    });
  };

  return { cancelJob, isPending, isConfirming, isSuccess, error, hash };
}

// ---------------------------------------------------------------------------
// Job status enum (mirrors XcrowTypes.JobStatus)
// ---------------------------------------------------------------------------

export const JOB_STATUS = {
  0: "Created",
  1: "Accepted",
  2: "InProgress",
  3: "Completed",
  4: "Settled",
  5: "Disputed",
  6: "Cancelled",
  7: "Refunded",
  8: "Expired",
} as const;

export type Job = {
  jobId: bigint;
  agentId: bigint;
  agentChainId: number;
  client: `0x${string}`;
  agentWallet: `0x${string}`;
  amount: bigint;
  platformFee: bigint;
  taskHash: `0x${string}`;
  deadline: bigint;
  createdAt: bigint;
  settledAt: bigint;
  proofOfWorkHash: `0x${string}`;
  proofSubmittedAt: bigint;
  status: number;
  isCrossChain: boolean;
  destinationDomain: number;
};

// ---------------------------------------------------------------------------
// Read: jobs created by a client wallet (via AgentHired events on router)
// The escrow's clientJobs maps router address → jobs, not the user's address,
// so we scan router events instead.
// ---------------------------------------------------------------------------

export function useClientJobs(address: `0x${string}` | undefined) {
  const publicClient = usePublicClient({ chainId: arc.id });
  const [jobIds, setJobIds] = useState<bigint[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetch = async (showSpinner = false) => {
    if (!address || !publicClient) return;
    if (showSpinner) setIsLoading(true);
    setError(null);
    try {
      const DEPLOY_BLOCK = BigInt(33670294); // XcrowRouter deployment block (v5 — completeAndSettle)
      const CHUNK_SIZE = BigInt(9000);       // Arc testnet: 10k block limit per getLogs
      const latestBlock = await publicClient.getBlockNumber();

      const agentHiredEvent = {
        name: "AgentHired",
        type: "event",
        inputs: [
          { name: "jobId",      type: "uint256", indexed: true  },
          { name: "agentId",    type: "uint256", indexed: true  },
          { name: "client",     type: "address", indexed: true  },
          { name: "amount",     type: "uint256", indexed: false },
          { name: "crossChain", type: "bool",    indexed: false },
        ],
      } as const;

      // Build chunk ranges from NEWEST to OLDEST. Most users care about recent
      // jobs, and Arc Testnet has thousands of blocks between deploy and now,
      // so scanning oldest-first means waiting many seconds before recent
      // hires show up.
      const ranges: { from: bigint; to: bigint }[] = [];
      for (let to = latestBlock; to >= DEPLOY_BLOCK; to -= CHUNK_SIZE + BigInt(1)) {
        const from = to - CHUNK_SIZE < DEPLOY_BLOCK ? DEPLOY_BLOCK : to - CHUNK_SIZE;
        ranges.push({ from, to });
        if (from === DEPLOY_BLOCK) break;
      }

      // Fetch chunks sequentially with retries+backoff. Arc Testnet's public
      // RPC aggressively rate-limits (429), so parallel Promise.all calls fail
      // wholesale. We serialize and retry up to 4 times per chunk.
      const fetchChunk = async (
        from: bigint,
        to: bigint,
        attempt = 0,
      ): Promise<{ args: { jobId: bigint } }[]> => {
        try {
          const logs = await publicClient.getLogs({
            address: XCROW_ROUTER_ADDRESS,
            event: agentHiredEvent,
            args: { client: address },
            fromBlock: from,
            toBlock: to,
          });
          return logs as unknown as { args: { jobId: bigint } }[];
        } catch (err) {
          if (attempt >= 4) throw err;
          // Exponential backoff: 400ms, 800ms, 1600ms, 3200ms
          const backoff = 400 * 2 ** attempt;
          await new Promise((r) => setTimeout(r, backoff));
          return fetchChunk(from, to, attempt + 1);
        }
      };

      // Progressive update: surface jobs as soon as each chunk completes so
      // the user sees recent hires immediately, even while older chunks are
      // still being scanned.
      const accumulated: bigint[] = [];
      let firstHitYet = false;
      for (const { from, to } of ranges) {
        const logs = await fetchChunk(from, to);
        if (logs.length > 0) {
          accumulated.push(...logs.map((l) => l.args.jobId));
          const sorted = [...accumulated].sort((a, b) => (a > b ? -1 : 1));
          setJobIds(sorted);
          if (!firstHitYet) {
            setIsLoading(false);
            firstHitYet = true;
          }
        }
        // Small gap between chunks to stay under the rate-limit window.
        await new Promise((r) => setTimeout(r, 150));
      }
    } catch (e: unknown) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetch(true); // show spinner on first load only
    const interval = setInterval(() => fetch(false), 30000); // silent re-scan every 30s
    return () => clearInterval(interval);
  }, [address, publicClient]);

  return { jobIds, isLoading, error, refetch: fetch };
}

// ---------------------------------------------------------------------------
// Read: jobs assigned to an ERC-8004 agentId
// ---------------------------------------------------------------------------

export function useAgentJobs(
  wallet: `0x${string}` | undefined,
  ownedAgentIds?: readonly (bigint | number)[],
) {
  // Path A: jobs created via hireAgentByWalletWithPermit are indexed by the
  // agent's payout wallet (EOA hires use this).
  const byWallet = useReadContract({
    address: XCROW_ESCROW_ADDRESS,
    abi: XCROW_ESCROW_ABI,
    functionName: "getAgentWalletJobs",
    args: wallet ? [wallet] : undefined,
    chainId: arc.id,
    query: { enabled: !!wallet, staleTime: 0, refetchInterval: 30000 },
  });

  // Path B: jobs created via hireAgent(agentId) are indexed by the Arcade
  // agentId (Circle wallet hires use this). Batch-read getAgentJobs for every
  // agent the owner controls.
  const agentIdsForRead = (ownedAgentIds ?? []).filter(
    (id) => id !== undefined && id !== null,
  );
  const byId = useReadContracts({
    contracts: agentIdsForRead.map((id) => ({
      address: XCROW_ESCROW_ADDRESS,
      abi: XCROW_ESCROW_ABI,
      functionName: "getAgentJobs",
      args: [BigInt(id)],
      chainId: arc.id,
    })),
    query: {
      enabled: agentIdsForRead.length > 0,
      staleTime: 0,
      refetchInterval: 30000,
    },
  });

  // Merge + dedupe.
  const merged = new Map<string, bigint>();
  ((byWallet.data as bigint[] | undefined) ?? []).forEach((id) => {
    merged.set(id.toString(), id);
  });
  (byId.data ?? []).forEach((res: { result?: unknown }) => {
    const ids = res?.result as bigint[] | undefined;
    ids?.forEach((id) => merged.set(id.toString(), id));
  });

  const jobIds = Array.from(merged.values()).sort((a, b) =>
    a > b ? -1 : 1,
  );

  return {
    jobIds,
    isLoading: byWallet.isLoading || byId.isLoading,
    error: byWallet.error || byId.error,
    refetch: async () => {
      await byWallet.refetch();
      await byId.refetch();
    },
  };
}

// ---------------------------------------------------------------------------
// Read: single job details
// ---------------------------------------------------------------------------

export function useJob(jobId: bigint | null) {
  const { data, isLoading, error, refetch } = useReadContract({
    address: XCROW_ESCROW_ADDRESS,
    abi: XCROW_ESCROW_ABI,
    functionName: "getJob",
    args: jobId !== null ? [jobId] : undefined,
    chainId: arc.id,
    query: { enabled: jobId !== null, staleTime: 0, refetchInterval: 30000 },
  });
  return { job: data as Job | undefined, isLoading, error, refetch };
}

// ---------------------------------------------------------------------------
// Write: agent accepts a job
// ---------------------------------------------------------------------------

export function useRejectJob() {
  const { data: hash, writeContractAsync, isPending, error } = useArcadeWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  const rejectJob = async (jobId: bigint) => {
    return writeContractAsync({
      address: XCROW_ROUTER_ADDRESS,
      abi: XCROW_ROUTER_ABI,
      functionName: "rejectJobViaRouter",
      args: [jobId] as [bigint],
      chainId: arc.id,
    });
  };

  return { rejectJob, isPending, isConfirming, isSuccess, error, hash };
}

// ---------------------------------------------------------------------------
// Write: agent marks job complete
// ---------------------------------------------------------------------------

export function useCompleteJob() {
  const { data: hash, writeContractAsync, isPending, error } = useArcadeWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  const completeJob = async (jobId: bigint) => {
    return writeContractAsync({
      address: XCROW_ESCROW_ADDRESS,
      abi: XCROW_ESCROW_ABI,
      functionName: "completeJob",
      args: [jobId],
      chainId: arc.id,
    });
  };

  return { completeJob, isPending, isConfirming, isSuccess, error, hash };
}

// ---------------------------------------------------------------------------
// Write: agent submits proof of work (output hash on-chain)
// ---------------------------------------------------------------------------

export function useSubmitProofOfWork() {
  const { data: hash, writeContractAsync, isPending, error } = useArcadeWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  const submitProof = async (jobId: bigint, proofHash: `0x${string}`) => {
    return writeContractAsync({
      address: XCROW_ESCROW_ADDRESS,
      abi: XCROW_ESCROW_ABI,
      functionName: "submitProofOfWork",
      args: [jobId, proofHash],
      chainId: arc.id,
    });
  };

  return { submitProof, isPending, isConfirming, isSuccess, error, hash };
}

// ---------------------------------------------------------------------------
// Write: anyone triggers auto-settlement after PoW window elapses
// ---------------------------------------------------------------------------

export function useAutoSettle() {
  const { data: hash, writeContractAsync, isPending, error } = useArcadeWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  const autoSettle = async (jobId: bigint) => {
    return writeContractAsync({
      address: XCROW_ROUTER_ADDRESS,
      abi: XCROW_ROUTER_ABI,
      functionName: "autoSettleViaRouter",
      args: [jobId],
      chainId: arc.id,
    });
  };

  return { autoSettle, isPending, isConfirming, isSuccess, error, hash };
}

// ---------------------------------------------------------------------------
// Write: client disputes a job during the settlement window
// ---------------------------------------------------------------------------

export function useDisputeJob() {
  const { data: hash, writeContractAsync, isPending, error } = useArcadeWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  const disputeJob = async (jobId: bigint, reason: string) => {
    return writeContractAsync({
      address: XCROW_ROUTER_ADDRESS,
      abi: XCROW_ROUTER_ABI,
      functionName: "disputeJobViaRouter",
      args: [jobId, reason],
      chainId: arc.id,
    });
  };

  return { disputeJob, isPending, isConfirming, isSuccess, error, hash };
}

// ---------------------------------------------------------------------------
// Read: settlement window duration (seconds)
// ---------------------------------------------------------------------------

export function useSettlementWindow() {
  const { data } = useReadContract({
    address: XCROW_ESCROW_ADDRESS,
    abi: XCROW_ESCROW_ABI,
    functionName: "settlementWindow",
    chainId: arc.id,
  });
  return (data as bigint | undefined) ?? BigInt(0);
}

// ---------------------------------------------------------------------------
// Write: client submits star rating after job settled
// ---------------------------------------------------------------------------

export function useSubmitFeedback() {
  const publicClient = usePublicClient({ chainId: arc.id });
  const { writeContractAsync: xcrowWrite } = useArcadeWriteContract();
  const { writeContractAsync: erc8004Write } = useArcadeWriteContract();
  const [isPending, setIsPending] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const submitFeedback = async (
    jobId: bigint,
    stars: number,
    comment: string,
    erc8004AgentId: bigint,
    agentAddress: string,
    clientAddress: string,
  ) => {
    setIsPending(false);
    setIsConfirming(false);
    setIsSuccess(false);
    setError(null);

    // Upload comment to IPFS if provided
    let feedbackURI = "";
    let feedbackHash: `0x${string}` = "0x0000000000000000000000000000000000000000000000000000000000000000";

    if (comment.trim()) {
      const pinataJwt = process.env.NEXT_PUBLIC_PINATA_JWT;
      if (pinataJwt) {
        try {
          const body = JSON.stringify({
            pinataContent: { rating: stars, comment, jobId: jobId.toString(), timestamp: Date.now() },
            pinataMetadata: { name: `xcrow-review-${jobId}` },
          });
          const res = await fetch("https://api.pinata.cloud/pinning/pinJSONToIPFS", {
            method: "POST",
            headers: { Authorization: `Bearer ${pinataJwt}`, "Content-Type": "application/json" },
            body,
          });
          if (res.ok) {
            const data = await res.json();
            feedbackURI = `ipfs://${data.IpfsHash}`;
            const enc = new TextEncoder().encode(comment);
            const digest = await crypto.subtle.digest("SHA-256", enc);
            feedbackHash = `0x${Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("")}` as `0x${string}`;
          }
        } catch {}
      }
    }

    try {
      // Step 1: XcrowRouter.submitFeedback
      setIsPending(true);
      const xcrowHash = await xcrowWrite({
        address: XCROW_ROUTER_ADDRESS,
        abi: XCROW_ROUTER_ABI,
        functionName: "submitFeedback",
        args: [jobId, BigInt(stars), 0, "rating", feedbackURI, feedbackHash],
        chainId: arc.id,
      });
      setIsPending(false);
      setIsConfirming(true);
      await publicClient!.waitForTransactionReceipt({ hash: xcrowHash });

      // Step 2: ERC-8004 ReputationRegistry.giveFeedback (only if agent has ERC-8004 identity)
      if (erc8004AgentId > BigInt(0)) {
        setIsPending(true);
        setIsConfirming(false);
        const erc8004Hash = await erc8004Write({
          address: ERC8004_REPUTATION_ADDRESS,
          abi: ERC8004_REPUTATION_ABI,
          functionName: "giveFeedback",
          args: [erc8004AgentId, BigInt(stars), 0, "rating", "", "", feedbackURI, feedbackHash],
          chainId: arc.id,
        });
        setIsPending(false);
        setIsConfirming(true);
        await publicClient!.waitForTransactionReceipt({ hash: erc8004Hash });
      }

      setIsConfirming(false);

      // Step 3: Cache in Supabase reviews table
      await supabase.from("reviews").insert({
        job_id: jobId.toString(),
        agent_id: erc8004AgentId.toString(),
        agent_address: agentAddress.toLowerCase(),
        stars,
        comment_uri: feedbackURI || null,
        client_address: clientAddress.toLowerCase(),
      });

      setIsSuccess(true);
    } catch (e: any) {
      setIsPending(false);
      setIsConfirming(false);
      setError(e);
      throw e;
    }
  };

  return { submitFeedback, isPending, isConfirming, isSuccess, error };
}

// ---------------------------------------------------------------------------
// Total USDC earned by an agent wallet from settled Xcrow jobs
// ---------------------------------------------------------------------------

export function useAgentXcrowEarnings(wallet: `0x${string}` | undefined) {
  const publicClient = usePublicClient({ chainId: arc.id });
  const [totalUsdc, setTotalUsdc] = useState<number>(0);
  const [jobCount, setJobCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!wallet || !publicClient) return;

    const fetch = async () => {
      try {
        const jobIds = await publicClient.readContract({
          address: XCROW_ESCROW_ADDRESS,
          abi: XCROW_ESCROW_ABI,
          functionName: "getAgentWalletJobs",
          args: [wallet],
        }) as bigint[];

        if (!jobIds || jobIds.length === 0) {
          setTotalUsdc(0);
          setJobCount(0);
          setIsLoading(false);
          return;
        }

        const jobs = await Promise.all(
          jobIds.map((id) =>
            publicClient.readContract({
              address: XCROW_ESCROW_ADDRESS,
              abi: XCROW_ESCROW_ABI,
              functionName: "getJob",
              args: [id],
            })
          )
        );

        let total = BigInt(0);
        let settled = 0;
        for (const job of jobs as any[]) {
          // status 4 = Settled
          if (job.status === 4) {
            total += BigInt(job.amount) - BigInt(job.platformFee);
            settled++;
          }
        }
        setTotalUsdc(Number(total) / 1e6);
        setJobCount(settled);
      } catch {
        // silent — show 0 on error
      } finally {
        setIsLoading(false);
      }
    };

    fetch();
    const interval = setInterval(fetch, 60000);
    return () => clearInterval(interval);
  }, [wallet, publicClient]);

  return { totalUsdc, jobCount, isLoading };
}

/** Fetch Xcrow earnings for a specific agent by its wallet address */
export function useAgentXcrowEarningsById(_agentId: number) {
  // We use the owner wallet approach since Arcade Registry IDs don't match ERC-8004 IDs
  // The agent card passes Arcade IDs but we need to look up by wallet
  const publicClient = usePublicClient({ chainId: arc.id });
  const { address } = useArcadeWallet();
  const [totalUsdc, setTotalUsdc] = useState<number>(0);
  const [jobCount, setJobCount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!address || !publicClient) return;

    const fetchEarnings = async () => {
      try {
        const jobIds = await publicClient.readContract({
          address: XCROW_ESCROW_ADDRESS,
          abi: XCROW_ESCROW_ABI,
          functionName: "getAgentWalletJobs",
          args: [address],
        }) as bigint[];

        if (!jobIds || jobIds.length === 0) {
          setTotalUsdc(0);
          setJobCount(0);
          setIsLoading(false);
          return;
        }

        const jobs = await Promise.all(
          jobIds.map((id) =>
            publicClient.readContract({
              address: XCROW_ESCROW_ADDRESS,
              abi: XCROW_ESCROW_ABI,
              functionName: "getJob",
              args: [id],
            })
          )
        );

        let total = BigInt(0);
        let settled = 0;
        for (const job of jobs as any[]) {
          if (job.status === 4) {
            total += BigInt(job.amount) - BigInt(job.platformFee);
            settled++;
          }
        }
        setTotalUsdc(Number(total) / 1e6);
        setJobCount(settled);
      } catch {
        // silent
      } finally {
        setIsLoading(false);
      }
    };

    fetchEarnings();
    const interval = setInterval(fetchEarnings, 60000);
    return () => clearInterval(interval);
  }, [address, publicClient]);

  return { totalUsdc, jobCount, isLoading };
}
