import { NextResponse } from "next/server";

const CIRCLE_BASE_URL =
  process.env.NEXT_PUBLIC_CIRCLE_BASE_URL ?? "https://api.circle.com";
const CIRCLE_API_KEY = process.env.CIRCLE_API_KEY;

type ActionPayload = {
  action:
    | "createDeviceToken"
    | "initializeUser"
    | "listWallets"
    | "getTokenBalance"
    | "createTransaction"
    | "getTransaction"
    | "listTransactions";
  deviceId?: string;
  userToken?: string;
  walletId?: string;
  // createTransaction params
  contractAddress?: string;
  abiFunctionSignature?: string;
  abiParameters?: unknown[];
  amount?: string;
  feeLevel?: "LOW" | "MEDIUM" | "HIGH";
  // getTransaction params
  transactionId?: string;
  // listTransactions params
  pageSize?: number;
};

function authHeaders(userToken?: string): HeadersInit {
  if (!CIRCLE_API_KEY) {
    throw new Error("CIRCLE_API_KEY is not configured");
  }
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${CIRCLE_API_KEY}`,
  };
  if (userToken) headers["X-User-Token"] = userToken;
  return headers;
}

export async function POST(request: Request) {
  if (!CIRCLE_API_KEY) {
    return NextResponse.json(
      { error: "Server misconfigured: CIRCLE_API_KEY is not set" },
      { status: 500 },
    );
  }

  let body: ActionPayload;
  try {
    body = (await request.json()) as ActionPayload;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const { action, ...params } = body;
  if (!action) {
    return NextResponse.json({ error: "Missing action" }, { status: 400 });
  }

  try {
    switch (action) {
      case "createDeviceToken": {
        const { deviceId } = params;
        if (!deviceId) {
          return NextResponse.json(
            { error: "Missing deviceId" },
            { status: 400 },
          );
        }

        const response = await fetch(
          `${CIRCLE_BASE_URL}/v1/w3s/users/social/token`,
          {
            method: "POST",
            headers: authHeaders(),
            body: JSON.stringify({
              idempotencyKey: crypto.randomUUID(),
              deviceId,
            }),
          },
        );

        const data = await response.json();
        if (!response.ok) {
          return NextResponse.json(data, { status: response.status });
        }
        // Returns { deviceToken, deviceEncryptionKey }
        return NextResponse.json(data.data, { status: 200 });
      }

      case "initializeUser": {
        const { userToken } = params;
        if (!userToken) {
          return NextResponse.json(
            { error: "Missing userToken" },
            { status: 400 },
          );
        }

        const response = await fetch(
          `${CIRCLE_BASE_URL}/v1/w3s/user/initialize`,
          {
            method: "POST",
            headers: authHeaders(userToken),
            body: JSON.stringify({
              idempotencyKey: crypto.randomUUID(),
              accountType: "SCA",
              blockchains: ["ARC-TESTNET"],
            }),
          },
        );

        const data = await response.json();
        if (!response.ok) {
          return NextResponse.json(data, { status: response.status });
        }
        // Returns { challengeId }
        return NextResponse.json(data.data, { status: 200 });
      }

      case "listWallets": {
        const { userToken } = params;
        if (!userToken) {
          return NextResponse.json(
            { error: "Missing userToken" },
            { status: 400 },
          );
        }

        const response = await fetch(`${CIRCLE_BASE_URL}/v1/w3s/wallets`, {
          method: "GET",
          headers: authHeaders(userToken),
        });

        const data = await response.json();
        if (!response.ok) {
          return NextResponse.json(data, { status: response.status });
        }
        // Returns { wallets: [...] }
        return NextResponse.json(data.data, { status: 200 });
      }

      case "getTokenBalance": {
        const { userToken, walletId } = params;
        if (!userToken || !walletId) {
          return NextResponse.json(
            { error: "Missing userToken or walletId" },
            { status: 400 },
          );
        }

        const response = await fetch(
          `${CIRCLE_BASE_URL}/v1/w3s/wallets/${walletId}/balances`,
          {
            method: "GET",
            headers: authHeaders(userToken),
          },
        );

        const data = await response.json();
        if (!response.ok) {
          return NextResponse.json(data, { status: response.status });
        }
        // Returns { tokenBalances: [...] }
        return NextResponse.json(data.data, { status: 200 });
      }

      case "createTransaction": {
        const {
          userToken,
          walletId,
          contractAddress,
          abiFunctionSignature,
          abiParameters,
          amount,
          feeLevel,
        } = params;
        if (
          !userToken ||
          !walletId ||
          !contractAddress ||
          !abiFunctionSignature
        ) {
          return NextResponse.json(
            {
              error:
                "Missing userToken, walletId, contractAddress, or abiFunctionSignature",
            },
            { status: 400 },
          );
        }

        // Build payload — `amount` is only valid for payable functions,
        // omit it when zero or unset to avoid Circle's "API parameter invalid".
        // User-controlled wallets use a flat `feeLevel` at the top level, not
        // the `fee: { type, config }` wrapper used by developer-controlled wallets.
        const hasAmount = amount && amount !== "0";
        const payload: Record<string, unknown> = {
          idempotencyKey: crypto.randomUUID(),
          walletId,
          contractAddress,
          abiFunctionSignature,
          abiParameters: abiParameters ?? [],
          feeLevel: feeLevel ?? "MEDIUM",
        };
        if (hasAmount) payload.amount = amount;

        console.log(
          "[circle/createTransaction] payload:",
          JSON.stringify(payload),
        );

        const response = await fetch(
          `${CIRCLE_BASE_URL}/v1/w3s/user/transactions/contractExecution`,
          {
            method: "POST",
            headers: authHeaders(userToken),
            body: JSON.stringify(payload),
          },
        );

        if (!response.ok) {
          const errBody = await response.text();
          console.error(
            "[circle/createTransaction] Circle rejected:",
            response.status,
            errBody,
          );
          // Return Circle's full response so the client can surface it.
          try {
            return NextResponse.json(JSON.parse(errBody), {
              status: response.status,
            });
          } catch {
            return NextResponse.json(
              { error: errBody },
              { status: response.status },
            );
          }
        }

        const data = await response.json();
        console.log(
          "[circle/createTransaction] success response:",
          JSON.stringify(data),
        );
        // Returns { id (transactionId), challengeId, state }
        return NextResponse.json(data.data, { status: 200 });
      }

      case "listTransactions": {
        const { userToken, walletId, pageSize } = params;
        if (!userToken) {
          return NextResponse.json(
            { error: "Missing userToken" },
            { status: 400 },
          );
        }
        const qs = new URLSearchParams();
        if (walletId) qs.set("walletIds", walletId);
        qs.set("pageSize", String(pageSize ?? 10));

        const response = await fetch(
          `${CIRCLE_BASE_URL}/v1/w3s/transactions?${qs.toString()}`,
          {
            method: "GET",
            headers: authHeaders(userToken),
          },
        );

        const data = await response.json();
        if (!response.ok) {
          return NextResponse.json(data, { status: response.status });
        }
        // Returns { transactions: [...] }
        return NextResponse.json(data.data, { status: 200 });
      }

      case "getTransaction": {
        const { userToken, transactionId } = params;
        if (!userToken || !transactionId) {
          return NextResponse.json(
            { error: "Missing userToken or transactionId" },
            { status: 400 },
          );
        }

        const response = await fetch(
          `${CIRCLE_BASE_URL}/v1/w3s/transactions/${transactionId}`,
          {
            method: "GET",
            headers: authHeaders(userToken),
          },
        );

        const data = await response.json();
        if (!response.ok) {
          return NextResponse.json(data, { status: response.status });
        }
        // Returns { transaction: { id, state, txHash, ... } }
        return NextResponse.json(data.data, { status: 200 });
      }

      default:
        return NextResponse.json(
          { error: `Unknown action: ${action}` },
          { status: 400 },
        );
    }
  } catch (error) {
    console.error("Error in /api/circle:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
